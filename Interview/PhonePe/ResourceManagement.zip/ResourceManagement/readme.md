# Resource mangement system.

run below command on the folder and make is module 

``` pip3 install -e .```

then run manager file.